import json
import os
import statistics

os.chdir(os.path.dirname(os.path.abspath(__file__)))
print(f'Current working directory: {os.getcwd()}')

current_dir = '.'

# print(os.path.isdir(os.path.join(current_dir,'output_Donald','Recursive')))

# print(os.path.basename(os.path.join(current_dir,'output_Donald','Recursive')))


def create_statistics(dir_names=['output_Donald','output_FBI','output_USA']):
    current_dir = '.'

    recursive_cosine_similarity_list = []
    semantic_cosine_similarity_list = []
    token_cosine_similarity_list = []

    for dir in dir_names:
        pass
